<template>
  <section>
    <div class="row at-row flex-center flex-middle">
      <div class="col-lg-24">
        <hr class="footspace">
      </div>
    </div>
    <div class="row at-row flex-center flex-middle">
      <div class="col-lg-6">
      </div>
      <div class="col-lg-12 credits">
        Kenef AŞ.
      </div>
      <div class="col-lg-6">
      </div>
    </div>
    <div class="row at-row flex-center flex-middle credits-tag">
      <div class="col-lg-6">
      </div>
      <div class="col-lg-6">
      </div>
    </div>
    <div class="row at-row flex-center flex-middle credits-other">
      <div class="col-lg-6">
      </div>
      <div class="col-lg-12">
      </div>
      <div class="col-lg-6">
      </div>
    </div>
    <div class="row at-row flex-center flex-middle credits-other">
      <div class="col-lg-6">
      </div>
      <div class="col-lg-12">
      </div>
      <div class="col-lg-6">
      </div>
    </div>
   <div class="row at-row flex-center flex-middle">
      <div class="col-lg-24">
        <h1>
          <!-- modifying code here -->
          </h1>
      </div>
   </div>
  </section>
</template>
